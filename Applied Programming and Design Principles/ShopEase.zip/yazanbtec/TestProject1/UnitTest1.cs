using NUnit.Framework;
using System.IO;
using System;
using yazanbtec;

namespace TestProject
{
    [TestFixture]
    public class ProductTests
    {
        [Test]
        public void TestAddProduct_ShouldAddProductSuccessfully()
        {
            // Arrange: Define the product data
            string type = "Electronics";
            string size = "Large";
            string color = "Black";
            string price = "299.99";
            string stock = "50";

            // Act: Call the AddProduct method
            Product.AddProduct(type, size, color, price, stock);

            // Assert: Assuming no exception occurs
            Assert.Pass("Product added successfully!");
        }
        [Test]
        public void TestAddProduct1_ShouldAddProductSuccessfully()
        {
            // Arrange: Define the product data
            string type = "Dress";
            string size = "L";
            string color = "Black";
            string price = "299.99";
            string stock = "50";

            // Act: Call the AddProduct method
            Product.AddProduct(type, size, color, price, stock);

            // Assert: Assuming no exception occurs
            Assert.Pass("Product added successfully!");
        }

        [Test]
        public void TestUpdateProduct_ShouldUpdateProductSuccessfully()
        {
            // Arrange: Define product data to update
            string id = "18";
            string newType = "Updated Electronics";
            string newSize = "Medium";
            string newColor = "Blue";
            string newPrice = "199.99";
            string newStock = "25";

            // Act: Call the UpdateProduct method
            Product.UpdateProduct(id, newType, newSize, newColor, newPrice, newStock);

            // Assert: Assuming no exception occurs
            Assert.Pass("Product updated successfully!");
        }

        [Test]
        public void TestDeleteProduct_ShouldDeleteProductSuccessfully()
        {
            // Arrange: Define the product ID to delete
            string productId = "1";

            // Act: Call the DeleteProduct method
            Product.DeleteProduct(productId);

            // Assert: Assuming no exception occurs
            Assert.Pass("Product deleted successfully!");
        }

     

        [Test]
        public void TestSendNotification_ShouldSendNotificationSuccessfully()
        {
            // Arrange: Define product data for notification
            string type = "Electronics";
            string size = "Large";
            string color = "Black";
            string price = "299.99";
            string stock = "50";

            // Act: Call the SendNotificationToSubscribers method
            Product.SendNotificationToSubscribers(type, size, color, price, stock);

            Assert.Pass("Notifications sent successfully!");
        }
    }
}

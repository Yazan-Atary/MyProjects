using NUnit.Framework;
using yazanbtec;

namespace TestProject
{
    [TestFixture]
    public class ClientTests
    {
        private Client _client;

        [SetUp]
        public void Setup()
        {
            // This runs before every test, ideal for initializing objects
            _client = new Client(); // Initialize your client instance here
        }

        [Test]
        public void TestAddClient_ShouldAddClientSuccessfully()
        {
            // Arrange: Define a new client to add
            string name = "John Doe";
            string address = "123 Main St";
            string contact = "1234567890";

            // Act: Call the AddClient method
            _client.AddClient(name, address, contact);

            // Assert: Verify if the client was added successfully
            // Since there's no return type, you can assert based on internal state or output (modify as per your design)
            Assert.Pass("Client added successfully!"); // Example assertion, modify as needed
        }
    }
}

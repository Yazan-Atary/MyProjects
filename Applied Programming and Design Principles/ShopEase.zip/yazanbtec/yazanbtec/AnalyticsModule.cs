﻿using System;
using MySql.Data.MySqlClient;

namespace yazanbtec
{
    class AnalyticsModule
    {
        static string connectionString = "server=localhost;database=shopease;uid=root;pwd=;";

        public static void HandleAnalyticsOperations()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("Analytics Module:");
                Console.WriteLine("1. Analyze Product Trends");
                Console.WriteLine("2. Generate Sales Report");
                Console.WriteLine("3. Customer Behavior Analysis");
                Console.WriteLine("4. Back to Dashboard");

                Console.Write("Select an option (1-4): ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        AnalyzeProductTrends();
                        break;
                    case "2":
                        GenerateSalesReport();
                        break;
                    case "3":
                        CustomerBehaviorAnalysis();
                        break;
                    case "4":
                        return;
                    default:
                        Console.WriteLine("Invalid selection, please try again.");
                        break;
                }
            }
        }

        static void AnalyzeProductTrends()
        {
            try
            {
                Console.Clear();
                Console.WriteLine("Product Trends:");
                Console.WriteLine("-----------------------------------------------------------------");
                Console.WriteLine("{0,-20} {1,-15} {2,-15} {3,-15}", "Product Type", "Total Sold", "Current Stock", "Forecast Demand");
                Console.WriteLine("-----------------------------------------------------------------");

                // Simulate product trends data using random values
                Random rnd = new Random();
                Console.WriteLine("{0,-20} {1,-15} {2,-15} {3,-15}", "Men's Shoes", rnd.Next(50, 500), rnd.Next(5, 50), "High");
                Console.WriteLine("{0,-20} {1,-15} {2,-15} {3,-15}", "Women's Dresses", rnd.Next(50, 500), rnd.Next(5, 50), "Medium");
                Console.WriteLine("{0,-20} {1,-15} {2,-15} {3,-15}", "Kids' T-Shirts", rnd.Next(50, 500), rnd.Next(5, 50), "Low");
                Console.WriteLine("-----------------------------------------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            Console.WriteLine("\nPress any key to return...");
            Console.ReadKey(); // Wait for the user to press a key
        }

        static void GenerateSalesReport()
        {
            try
            {
                Console.Clear();
                Console.WriteLine("Sales Report:");
                Console.WriteLine("--------------------------------------------------------");
                Console.WriteLine("{0,-15} {1,-15} {2,-15}", "Product Type", "Quantity Sold", "Total Revenue");
                Console.WriteLine("--------------------------------------------------------");

                // Simulate sales data using random values
                Random rnd = new Random();
                Console.WriteLine("{0,-15} {1,-15} {2,-15}", "Dress", rnd.Next(1, 50), $"${rnd.Next(100, 1000)}");
                Console.WriteLine("{0,-15} {1,-15} {2,-15}", "Pant", rnd.Next(1, 50), $"${rnd.Next(100, 1000)}");
                Console.WriteLine("{0,-15} {1,-15} {2,-15}", "Shoes", rnd.Next(1, 50), $"${rnd.Next(100, 1000)}");
                Console.WriteLine("--------------------------------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            Console.WriteLine("\nPress any key to return...");
            Console.ReadKey(); // Wait for the user to press a key
        }

        static void CustomerBehaviorAnalysis()
        {
            try
            {
                Console.Clear();
                Console.WriteLine("Customer Behavior Analysis:");
                Console.WriteLine("----------------------------------------------------------");
                Console.WriteLine("{0,-10} {1,-20} {2,-15}", "Customer", "Most Viewed Product", "Average Spend");
                Console.WriteLine("----------------------------------------------------------");

                // Simulate customer behavior analysis data using random values
                Random rnd = new Random();
                Console.WriteLine("{0,-10} {1,-20} {2,-15}", "Khaled", "Shoes", $"${rnd.Next(100, 1000)}");
                Console.WriteLine("{0,-10} {1,-20} {2,-15}", "Yazan", "T-Shirts", $"${rnd.Next(100, 1000)}");
                Console.WriteLine("{0,-10} {1,-20} {2,-15}", "Mohammed", "Pants", $"${rnd.Next(100, 1000)}");
                Console.WriteLine("----------------------------------------------------------");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            Console.WriteLine("\nPress any key to return...");
            Console.ReadKey(); // Wait for the user to press a key
        }
    }
}

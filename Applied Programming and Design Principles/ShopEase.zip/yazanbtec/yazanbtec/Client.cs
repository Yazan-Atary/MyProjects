﻿using System;
using MySql.Data.MySqlClient;
using System.Collections.Generic;
using yazanbtec; // Import the correct namespace


namespace yazanbtec
{
    // Client class implements the Observer interface
    public class Client : IClientObserver
    {
        static string connectionString = "server=localhost;database=shopease;uid=root;pwd=;";

        public string Name { get; set; }

        public Client(string name)
        {
            Name = name;
        }

        // This method will be called by NotificationManager when a notification is sent
        public void Update(string message)
        {
            Console.WriteLine($"Notification for {Name}: {message}");
        }


        public static void HandleClientOperations()
        {
            string choice = string.Empty;

            while (choice != "5")
            {
                Console.Clear();
                Console.WriteLine("Client Management:");
                Console.WriteLine("1. Add Client");
                Console.WriteLine("2. Update Client");
                Console.WriteLine("3. Delete Client");
                Console.WriteLine("4. Show All Clients");
                Console.WriteLine("5. Back to Dashboard");

                Console.Write("Select an option (1-5): ");
                choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        AddClient();
                        break;
                    case "2":
                        UpdateClient();
                        break;
                    case "3":
                        DeleteClient();
                        break;
                    case "4":
                        ShowAllClients();
                        break;
                    case "5":
                        return;
                    default:
                        Console.WriteLine("Invalid selection, please try again.");
                        break;
                }
            }
        }

        public static void AddClient()
        {
            try
            {
                Console.Write("Enter Name: ");
                string name = Console.ReadLine();
                Console.Write("Enter Address: ");
                string address = Console.ReadLine();
                Console.Write("Enter Contact: ");
                string contact = Console.ReadLine();

                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "INSERT INTO clients (name, address, contact) VALUES (@name, @address, @contact)";
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@name", name);
                        cmd.Parameters.AddWithValue("@address", address);
                        cmd.Parameters.AddWithValue("@contact", contact);

                        cmd.ExecuteNonQuery();
                        Console.WriteLine("Client added successfully!");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            Console.ReadKey();
        }
        public static void UpdateClient()
        {
            try
            {
                Console.Write("Enter Client ID to update: ");
                string id = Console.ReadLine();

                Console.Write("Enter New Name: ");
                string name = Console.ReadLine();
                Console.Write("Enter New Address: ");
                string address = Console.ReadLine();
                Console.Write("Enter New Contact: ");
                string contact = Console.ReadLine();

                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "UPDATE clients SET name = @name, address = @address, contact = @contact WHERE id = @id";
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.Parameters.AddWithValue("@name", name);
                        cmd.Parameters.AddWithValue("@address", address);
                        cmd.Parameters.AddWithValue("@contact", contact);

                        cmd.ExecuteNonQuery();
                        Console.WriteLine("Client updated successfully!");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            Console.ReadKey();
        }


        public static void DeleteClient()
        {
            try
            {
                Console.Write("Enter Client ID to delete: ");
                string id = Console.ReadLine();

                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    string checkQuery = "SELECT COUNT(*) FROM clients WHERE id = @id";
                    using (MySqlCommand checkCmd = new MySqlCommand(checkQuery, conn))
                    {
                        checkCmd.Parameters.AddWithValue("@id", id);
                        int clientExists = Convert.ToInt32(checkCmd.ExecuteScalar());

                        if (clientExists > 0)
                        {
                            string deleteQuery = "DELETE FROM clients WHERE id = @id";
                            using (MySqlCommand deleteCmd = new MySqlCommand(deleteQuery, conn))
                            {
                                deleteCmd.Parameters.AddWithValue("@id", id);
                                deleteCmd.ExecuteNonQuery();
                                Console.WriteLine("Client deleted successfully!");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Client with ID {0} does not exist.", id);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            Console.ReadKey();
        }


        public static void ShowAllClients()
        {
            try
            {
                Console.Clear();

                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT * FROM clients";

                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            Console.WriteLine("All Clients:");
                            Console.WriteLine("--------------------------------------------------------");
                            Console.WriteLine("{0,-5} {1,-20} {2,-20} {3,-15}", "ID", "Name", "Address", "Contact");
                            Console.WriteLine("--------------------------------------------------------");

                            while (reader.Read())
                            {
                                string id = reader["id"].ToString();
                                string name = reader["name"].ToString();
                                string address = reader["address"].ToString();
                                string contact = reader["contact"].ToString();
                                Console.WriteLine("{0,-5} {1,-20} {2,-20} {3,-15}", id, name, address, contact);
                            }

                            Console.WriteLine("--------------------------------------------------------");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }

            Console.ReadKey();
        }
    }
}
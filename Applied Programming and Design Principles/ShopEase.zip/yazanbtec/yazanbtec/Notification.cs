﻿using System;
using MySql.Data.MySqlClient;
using System.Data;
using System.Collections.Generic;

namespace yazanbtec
{
    // Observer interface for clients
    public interface IClientObserver
    {
        void Update(string message);  // This method will be called when a notification is sent
    }

    // Singleton NotificationManager acting as the Subject (Publisher)
    public class NotificationManager
    {
        private static NotificationManager _instance;  // Singleton instance
        private static readonly object _lock = new object();  // Thread safety
        private List<IClientObserver> _observers = new List<IClientObserver>();  // List of observers (clients)

        private static string connectionString = "server=localhost;database=shopease;uid=root;pwd=;";

        // Private constructor to prevent instantiation from outside
        private NotificationManager() { }

        // Singleton instance access
        public static NotificationManager GetInstance()
        {
            if (_instance == null)
            {
                lock (_lock)
                {
                    if (_instance == null)
                    {
                        _instance = new NotificationManager();
                    }
                }
            }
            return _instance;
        }

        // Attach a client observer
        public void Attach(IClientObserver observer)
        {
            _observers.Add(observer);
            Console.WriteLine("Client subscribed for notifications.");
        }

        // Detach a client observer
        public void Detach(IClientObserver observer)
        {
            _observers.Remove(observer);
            Console.WriteLine("Client unsubscribed from notifications.");
        }

        // Notify all attached observers (clients)
        public void Notify(string message)
        {
            foreach (var observer in _observers)
            {
                observer.Update(message);  // Call update method on each observer
            }
        }

     

        // Methods to manage notification in the database
        public void SendManualNotification()
        {
            try
            {
                Console.Write("Enter Notification Message: ");
                string message = Console.ReadLine();

                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    // Select all subscribers
                    string selectSubscribersQuery = "SELECT name FROM subscribers";
                    using (MySqlCommand selectCmd = new MySqlCommand(selectSubscribersQuery, conn))
                    {
                        using (MySqlDataReader reader = selectCmd.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                // Create a list to store the subscriber names
                                var subscribers = new List<string>();

                                while (reader.Read())
                                {
                                    string subscriberName = reader["name"].ToString();
                                    subscribers.Add(subscriberName);  // Add subscriber name to the list
                                }

                                reader.Close();  // Close the reader before reusing the connection

                                // Display message before inserting notifications
                                Console.WriteLine("Sending notification to all clients...");

                                // Insert notifications for each subscriber
                                foreach (string subscriber in subscribers)
                                {
                                    InsertNotification(conn, subscriber, message);
                                }

                                // Display confirmation after sending notifications
                                Console.WriteLine("Manual notification sent to all subscribers!");
                            }
                            else
                            {
                                Console.WriteLine("No subscribers found.");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            Console.ReadLine();  // Wait for the user to press a key
        }

        public void ShowAllNotifications()
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT * FROM notifications";

                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            Console.WriteLine("All Notifications:");
                            Console.WriteLine("-------------------------------------------------------------------------------------------------------------");
                            Console.WriteLine("{0,-20} {1,-60}", "Name", "Notification");
                            Console.WriteLine("-------------------------------------------------------------------------------------------------------------");

                            while (reader.Read())
                            {
                                string name = reader["name"].ToString();
                                string notification = reader["notification"].ToString();
                                Console.WriteLine("{0,-20} {1,-60}", name, notification);
                            }
                            Console.WriteLine("-------------------------------------------------------------------------------------------------------------");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            Console.ReadLine();  // Wait for the user to press a key
        }

        public void ClearAllNotifications()
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "DELETE FROM notifications";
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.ExecuteNonQuery();
                        Console.WriteLine("All notifications cleared!");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            Console.ReadLine();  // Wait for the user to press a key
        }

        // Private method to insert a notification in the database
        private void InsertNotification(MySqlConnection conn, string subscriberName, string message)
        {
            string query = "INSERT INTO notifications (name, notification) VALUES (@name, @notification)";
            using (MySqlCommand cmd = new MySqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@name", subscriberName);
                cmd.Parameters.AddWithValue("@notification", message);
                cmd.ExecuteNonQuery();
            }
        }
    }

    // Notification operations handler
    public static class Notification
    {
        public static void HandleNotificationOperations()
        {
            string option = string.Empty;

            while (option != "4")
            {
                Console.Clear();  // Clear the console at the start of each notification operation
                Console.WriteLine("Notification Management:");
                Console.WriteLine("1. Send Manual Notification");
                Console.WriteLine("2. Show All Notifications");
                Console.WriteLine("3. Clear ALL Notifications");
                Console.WriteLine("4. Back to Dashboard");
                Console.Write("Select an option (1–4): ");
                option = Console.ReadLine();

                // Get the singleton instance of NotificationManager
                NotificationManager notificationManager = NotificationManager.GetInstance();

                switch (option)
                {
                    case "1":
                        Console.Clear();  // Clear the console before sending a manual notification
                        notificationManager.SendManualNotification();
                        break;
                    case "2":
                        Console.Clear();  // Clear the console before showing notifications
                        notificationManager.ShowAllNotifications();
                        break;
                    case "3":
                        Console.Clear();  // Clear the console before clearing all notifications
                        notificationManager.ClearAllNotifications();
                        break;
                    case "4":
                        Console.Clear();  // Clear the console before going back to the dashboard
                        return;
                    default:
                        Console.WriteLine("Invalid option, please try again.");
                        break;
                }
            }
        }
    }
}

﻿using System;
using yazanbtec; // Ensure the correct namespace is included


namespace yazanbtec
{
    class Program
    {
        static void Main(string[] args)
        {
            string choice = string.Empty;

            // Welcome message
            Console.WriteLine("====================================================");
            Console.WriteLine("      Welcome to ShopEase - Your E-commerce Hub    ");
            Console.WriteLine("   Efficiently manage clients, products, and more!   ");
            Console.WriteLine("====================================================");
            Console.WriteLine("Press any key to continue to the dashboard...");
            Console.ReadKey();  // Wait for the user to press a key before continuing

            // Initialize the Facade
            ShopEaseFacade shopEaseFacade = new ShopEaseFacade();

            while (choice != "5")
            {
                Console.Clear();  // Clear the console before showing the main dashboard

                Console.WriteLine("Main Dashboard:");
                Console.WriteLine("1. Client Management");
                Console.WriteLine("2. Product Management");
                Console.WriteLine("3. Notification Management");
                Console.WriteLine("4. Analytics Module");
                Console.WriteLine("5. Exit");
                Console.Write("Select an option (1–5): ");
                choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        Console.Clear();  // Clear console before navigating to Client Management
                        shopEaseFacade.ManageClients();  // Using the Facade for Client Management
                        break;
                    case "2":
                        Console.Clear();  // Clear console before navigating to Product Management
                        shopEaseFacade.ManageProducts();  // Using the Facade for Product Management
                        break;
                    case "3":
                        Console.Clear();  // Clear console before navigating to Notification Management
                        shopEaseFacade.ManageNotifications();  // Using the Facade for Notification Management
                        break;
                    case "4":
                        Console.Clear();  // Clear console before navigating to Analytics Module
                        shopEaseFacade.ManageAnalytics();  // Using the Facade for Analytics Management
                        break;
                    case "5":
                        // Exit message
                        Console.Clear();
                        Console.WriteLine("====================================================");
                        Console.WriteLine("            Thank you for using ShopEase!                 ");
                        Console.WriteLine("   We hope to see you back soon for more management! ");
                        Console.WriteLine("====================================================");
                        Console.WriteLine("Press any key to exit...");
                        Console.ReadKey();  // Wait for user input before closing
                        return;
                    default:
                        Console.WriteLine("Invalid selection, please try again.");
                        break;
                }
            }
        }
    }
}

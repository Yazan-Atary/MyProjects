﻿namespace yazanbtec
{
    public class ShopEaseFacade
    {
        private readonly NotificationManager _notificationManager;
        private readonly Client _client;
        private readonly AnalyticsModule _analyticsModule;

        public ShopEaseFacade()
        {
            _notificationManager = NotificationManager.GetInstance(); // Singleton instance
            _client = new Client("Default Client Name"); // Passing a name to the Client constructor
            _analyticsModule = new AnalyticsModule(); // Instantiate AnalyticsModule
        }

        // Simplified interface for managing clients
        public void ManageClients()
        {
            Client.HandleClientOperations();
        }

        // Simplified interface for managing products (direct static access)
        public void ManageProducts()
        {
            Product.HandleProductOperations();
        }

        // Simplified interface for sending notifications
        public void ManageNotifications()
        {
            Notification.HandleNotificationOperations();
        }

        // Simplified interface for generating analytics
        public void ManageAnalytics()
        {
            AnalyticsModule.HandleAnalyticsOperations();
        }
    }
}

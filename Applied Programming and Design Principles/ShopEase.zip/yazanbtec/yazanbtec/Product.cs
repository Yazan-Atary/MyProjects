﻿using System;
using MySql.Data.MySqlClient;

namespace yazanbtec
{
    public static class Product
    {
        private static string connectionString = "server=localhost;database=shopease;uid=root;pwd=;";

        public static void HandleProductOperations()
        {
            string option = string.Empty;

            while (true)
            {
                Console.Clear();  // Clear the console at the start of each operation menu
                Console.WriteLine("Product Management:");
                Console.WriteLine("1. Add Product");
                Console.WriteLine("2. Update Product");
                Console.WriteLine("3. Delete Product");
                Console.WriteLine("4. Show All Products");
                Console.WriteLine("5. Back to Dashboard");
                Console.Write("Select an option (1–5): ");
                option = Console.ReadLine();

                switch (option)
                {
                    case "1":
                        Console.Clear();  // Clear the console before adding a product
                        AddProduct();
                        break;
                    case "2":
                        Console.Clear();  // Clear the console before updating a product
                        UpdateProduct();
                        break;
                    case "3":
                        Console.Clear();  // Clear the console before deleting a product
                        DeleteProduct();
                        break;
                    case "4":
                        Console.Clear();  // Clear the console before showing all products
                        ShowAllProducts();
                        break;
                    case "5":
                        Console.Clear();  // Clear the console before going back to the dashboard
                        return;
                    default:
                        Console.WriteLine("Invalid option, please try again.");
                        Console.WriteLine("Press any key to return to the main menu...");
                        Console.ReadKey();  // Wait for the user to press a key before clearing
                        break;
                }
            }
        }

        private static void AddProduct()
        {
            string type = PromptForInput("Enter Type: (or type 'back' to return): ");
            if (type.ToLower() == "back") return;

            string size = PromptForInput("Enter Size: (or type 'back' to return): ");
            if (size.ToLower() == "back") return;

            string color = PromptForInput("Enter Color: (or type 'back' to return): ");
            if (color.ToLower() == "back") return;

            string price = PromptForInput("Enter Price: (or type 'back' to return): ");
            if (price.ToLower() == "back") return;

            string stock = PromptForInput("Enter Stock: (or type 'back' to return): ");
            if (stock.ToLower() == "back") return;

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    // Add Product Query
                    string query = "INSERT INTO products (type, size, color, price, stock) VALUES (@type, @size, @color, @price, @stock)";
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@type", type);
                        cmd.Parameters.AddWithValue("@size", size);
                        cmd.Parameters.AddWithValue("@color", color);
                        cmd.Parameters.AddWithValue("@price", price);
                        cmd.Parameters.AddWithValue("@stock", stock);
                        cmd.ExecuteNonQuery();
                    }

                    Console.WriteLine("Product added successfully!");  // Success message
                    SendNotificationToSubscribers(type, size, color, price, stock);
                    Console.WriteLine("Press any key to return to the product management menu...");
                    Console.ReadKey();  // Wait for the user to acknowledge before going back
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }

        private static void UpdateProduct()
        {
            bool validId = false;
            do
            {
                string id = PromptForInput("Enter Product ID to update: (or type 'back' to return): ");
                if (id.ToLower() == "back") return;

                if (IsProductIdValid(id))
                {
                    string type = PromptForInput("Enter New Type: (or type 'back' to return): ");
                    if (type.ToLower() == "back") return;

                    string size = PromptForInput("Enter New Size: (or type 'back' to return): ");
                    if (size.ToLower() == "back") return;

                    string color = PromptForInput("Enter New Color: (or type 'back' to return): ");
                    if (color.ToLower() == "back") return;

                    string price = PromptForInput("Enter New Price: (or type 'back' to return): ");
                    if (price.ToLower() == "back") return;

                    string stock = PromptForInput("Enter New Stock: (or type 'back' to return): ");
                    if (stock.ToLower() == "back") return;

                    try
                    {
                        using (MySqlConnection conn = new MySqlConnection(connectionString))
                        {
                            conn.Open();

                            // Update Product Query
                            string query = "UPDATE products SET type = @type, size = @size, color = @color, price = @price, stock = @stock WHERE id = @id";
                            using (MySqlCommand cmd = new MySqlCommand(query, conn))
                            {
                                cmd.Parameters.AddWithValue("@id", id);
                                cmd.Parameters.AddWithValue("@type", type);
                                cmd.Parameters.AddWithValue("@size", size);
                                cmd.Parameters.AddWithValue("@color", color);
                                cmd.Parameters.AddWithValue("@price", price);
                                cmd.Parameters.AddWithValue("@stock", stock);
                                int affectedRows = cmd.ExecuteNonQuery();

                                if (affectedRows > 0)
                                {
                                    Console.WriteLine("Product updated successfully!");
                                    SendNotificationToSubscribers(type, size, color, price, stock);
                                    validId = true;  // Exit loop after successful update
                                }
                                else
                                {
                                    Console.WriteLine("Error: No product found with the given ID.");
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Error: " + ex.Message);
                    }
                }

            } while (!validId); // Keep prompting until a valid ID is provided
        }

        private static void DeleteProduct()
        {
            bool validId = false;
            do
            {
                string id = PromptForInput("Enter Product ID to delete: (or type 'back' to return): ");
                if (id.ToLower() == "back") return;

                if (IsProductIdValid(id))
                {
                    try
                    {
                        using (MySqlConnection conn = new MySqlConnection(connectionString))
                        {
                            conn.Open();

                            // Delete Product Query
                            string query = "DELETE FROM products WHERE id = @id";
                            using (MySqlCommand cmd = new MySqlCommand(query, conn))
                            {
                                cmd.Parameters.AddWithValue("@id", id);
                                int affectedRows = cmd.ExecuteNonQuery();

                                if (affectedRows > 0)
                                {
                                    Console.WriteLine("Product deleted successfully!");  // Success message
                                    validId = true;  // Exit loop after successful deletion
                                    Console.WriteLine("Press any key to return to the product management menu...");
                                    Console.ReadKey();  // Wait for the user to acknowledge before going back
                                }
                                else
                                {
                                    Console.WriteLine("Error: No product found with the given ID.");
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Error: " + ex.Message);
                    }
                }
                else
                {
                    Console.WriteLine("Invalid ID. Please try again.");
                }

            } while (!validId); // Keep prompting until a valid ID is provided
        }

        private static void ShowAllProducts()
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT * FROM products";

                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            Console.WriteLine("All Products:");
                            Console.WriteLine("-------------------------------------------------------------");
                            Console.WriteLine("{0,-5} {1,-10} {2,-10} {3,-10} {4,-10} {5,-10}", "ID", "Type", "Size", "Color", "Price", "Stock");
                            Console.WriteLine("-------------------------------------------------------------");

                            while (reader.Read())
                            {
                                string id = reader["id"].ToString();
                                string type = reader["type"].ToString();
                                string size = reader["size"].ToString();
                                string color = reader["color"].ToString();
                                string price = reader["price"].ToString();
                                string stock = reader["stock"].ToString();
                                Console.WriteLine("{0,-5} {1,-10} {2,-10} {3,-10} {4,-10} {5,-10}", id, type, size, color, price, stock);
                            }
                            Console.WriteLine("-------------------------------------------------------------");

                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            Console.ReadLine();  // Wait for the user to press a key
        }

        private static void SendNotificationToSubscribers(string type, string size, string color, string price, string stock)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    // Fetch all subscribers
                    string fetchSubscribersQuery = "SELECT name FROM subscribers";
                    using (MySqlCommand fetchSubscribersCmd = new MySqlCommand(fetchSubscribersQuery, conn))
                    {
                        using (MySqlDataReader reader = fetchSubscribersCmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                string subscriberName = reader["name"].ToString();

                                // Send Notification to each subscriber
                                using (MySqlConnection notificationConn = new MySqlConnection(connectionString))
                                {
                                    notificationConn.Open();
                                    string message = $"New product added: {type}, size: {size}, color: {color}, price: {price}$, stock: {stock}";

                                    string insertNotificationQuery = "INSERT INTO notifications (name, notification) VALUES (@name, @notification)";
                                    using (MySqlCommand notificationCmd = new MySqlCommand(insertNotificationQuery, notificationConn))
                                    {
                                        notificationCmd.Parameters.AddWithValue("@name", subscriberName);
                                        notificationCmd.Parameters.AddWithValue("@notification", message);
                                        notificationCmd.ExecuteNonQuery();
                                    }
                                }
                            }
                        }
                    }

                    Console.WriteLine("Notification sent to all subscribers!");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error sending notifications: " + ex.Message);
            }
        }

        // Prompt for valid input, re-ask if the input is empty
        private static string PromptForInput(string prompt)
        {
            string input;
            do
            {
                Console.Write(prompt);
                input = Console.ReadLine();
                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.WriteLine("Input cannot be empty. Please try again.");
                }
            } while (string.IsNullOrWhiteSpace(input));

            return input;
        }

        // Validate if the product ID exists in the database
        private static bool IsProductIdValid(string id)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    string checkQuery = "SELECT COUNT(*) FROM products WHERE id = @id";
                    using (MySqlCommand checkCmd = new MySqlCommand(checkQuery, conn))
                    {
                        checkCmd.Parameters.AddWithValue("@id", id);
                        int productExists = Convert.ToInt32(checkCmd.ExecuteScalar());

                        if (productExists > 0)
                        {
                            return true;
                        }
                        else
                        {
                            Console.WriteLine($"Product with ID {id} does not exist.");
                            return false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error validating product ID: " + ex.Message);
                return false;
            }
        }
    }
}

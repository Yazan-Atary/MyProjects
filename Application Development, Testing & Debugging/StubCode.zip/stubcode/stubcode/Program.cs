﻿using System;
using System.Collections.Generic;

public class Program
{
    public static void Main(string[] args)
    {
        // Create instances of the stubs
        ClientModuleStub clientStub = new ClientModuleStub();
        ProductModuleStub productStub = new ProductModuleStub();
        NotificationModuleStub notificationStub = new NotificationModuleStub();
        AnalyticsModuleStub analyticsStub = new AnalyticsModuleStub();

        Console.WriteLine("Testing Client, Product, Notification, and Analytics Module Stubs...");

        // 1. Add a Client
        Console.WriteLine("Adding Client...");
        string addClientResult = clientStub.AddClient("John Doe", "1234 Elm St", "1234567890");
        Console.WriteLine(addClientResult);

        // 2. Display all Clients
        Console.WriteLine("\nAll Clients:");
        List<string> clients = clientStub.GetAllClients();
        foreach (var client in clients)
        {
            Console.WriteLine(client);
        }

        // 3. Add a Product
        Console.WriteLine("\nAdding Product...");
        string addProductResult = productStub.AddProduct("Shoes", "42", "Red", "50", "10");
        Console.WriteLine(addProductResult);

        // 4. Display all Products
        Console.WriteLine("\nAll Products:");
        List<string> products = productStub.GetAllProducts();
        foreach (var product in products)
        {
            Console.WriteLine(product);
        }

        // 5. Send Notification
        Console.WriteLine("\nSending Notification to Clients...");
        string notifyResult = notificationStub.SendNotification("New product available: Shoes in Red, size 42!");
        Console.WriteLine(notifyResult);

        // 6. Analytics Module
        Console.WriteLine("\nGenerating Analytics Report...");
        string salesReport = analyticsStub.GenerateSalesReport();
        Console.WriteLine(salesReport);

        Console.WriteLine("\nPress any key to exit...");
        Console.ReadKey();
    }
}

// Stub class to simulate client operations
public class ClientModuleStub
{
    // Simulate adding a client to the system
    public string AddClient(string name, string address, string contact)
    {
        if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(contact))
        {
            return "Error: Client name and contact are required.";
        }
        return "Stub: Client added successfully!";
    }

    // Simulate fetching all clients
    public List<string> GetAllClients()
    {
        return new List<string>
        {
            "Stub: Client 1 - John Doe, Address: 1234 Elm St, Contact: 1234567890",
            "Stub: Client 2 - Jane Smith, Address: 5678 Oak St, Contact: 0987654321"
        };
    }
}

// Stub class to simulate product operations
public class ProductModuleStub
{
    public string AddProduct(string type, string size, string color, string price, string stock)
    {
        if (string.IsNullOrEmpty(type) || string.IsNullOrEmpty(price))
        {
            return "Error: Product type and price are required.";
        }
        return "Stub: Product added successfully!";
    }

    // Simulate fetching all products
    public List<string> GetAllProducts()
    {
        return new List<string>
        {
            "Stub: Product 1 - Shoes, Size: 42, Color: Red, Price: 50$, Stock: 10",
            "Stub: Product 2 - T-Shirt, Size: L, Color: Blue, Price: 20$, Stock: 30",
            "Stub: Product 3 - Jacket, Size: XL, Color: Black, Price: 60$, Stock: 15"
        };
    }
}

// Stub class to simulate notification operations
public class NotificationModuleStub
{
    public string SendNotification(string message)
    {
        if (string.IsNullOrEmpty(message))
        {
            return "Error: Notification message cannot be empty.";
        }

        return $"Stub: Notification sent successfully! Message: {message}";
    }
}

// Stub class to simulate analytics operations
public class AnalyticsModuleStub
{
    public string GenerateSalesReport()
    {
        return "Stub: Sales Report - Product A sold 100 units, Product B sold 50 units.";
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace yzbtecc
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }




        private void client_management_Click(object sender, EventArgs e)
        {
            // Create an instance of the ClientManagementForm
            Client clientForm = new Client();

            // Show the ClientManagementForm
            clientForm.Show();

            // Optionally, hide the current form (Main Dashboard)
            this.Hide();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            // Create an instance of the Product form
            Product productForm = new Product();

            // Show the Product form
            productForm.Show();

            // Optionally, hide the current form (Main Dashboard)
            this.Hide();
        }

        private void notification_management_Click(object sender, EventArgs e)
        {
            Notification notificationForm = new Notification();

            // Show the Product form
            notificationForm.Show();

            // Optionally, hide the current form (Main Dashboard)
            this.Hide();
        }

        private void analytics_report_Click(object sender, EventArgs e)
        {
            Analytics analyticsForm = new Analytics();

            // Show the Product form
            analyticsForm.Show();

            // Optionally, hide the current form (Main Dashboard)
            this.Hide();
        }

        private void Main_Load(object sender, EventArgs e)
        {

        }
    }
}

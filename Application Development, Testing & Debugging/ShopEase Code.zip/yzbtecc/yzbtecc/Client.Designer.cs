﻿namespace yzbtecc
{
    partial class Client
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Client));
            name = new TextBox();
            address = new TextBox();
            contact = new TextBox();
            ADD = new Button();
            Delete = new Button();
            Subscribe = new Button();
            Unsubscribe = new Button();
            Update = new Button();
            id = new TextBox();
            home = new Button();
            dataGridView1 = new DataGridView();
            dataGridView2 = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            SuspendLayout();
            // 
            // name
            // 
            name.Font = new Font("Segoe UI", 12F);
            name.Location = new Point(260, 302);
            name.Multiline = true;
            name.Name = "name";
            name.Size = new Size(236, 46);
            name.TabIndex = 3;
            // 
            // address
            // 
            address.Font = new Font("Segoe UI", 12F);
            address.Location = new Point(260, 409);
            address.Multiline = true;
            address.Name = "address";
            address.Size = new Size(236, 46);
            address.TabIndex = 4;
            // 
            // contact
            // 
            contact.Font = new Font("Segoe UI", 12F);
            contact.Location = new Point(260, 513);
            contact.Multiline = true;
            contact.Name = "contact";
            contact.Size = new Size(236, 46);
            contact.TabIndex = 5;
            // 
            // ADD
            // 
            ADD.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ADD.Location = new Point(105, 610);
            ADD.Name = "ADD";
            ADD.Size = new Size(175, 67);
            ADD.TabIndex = 6;
            ADD.Text = "ADD";
            ADD.UseVisualStyleBackColor = true;
            ADD.Click += ADD_Click;
            // 
            // Delete
            // 
            Delete.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            Delete.Location = new Point(346, 610);
            Delete.Name = "Delete";
            Delete.Size = new Size(175, 67);
            Delete.TabIndex = 7;
            Delete.Text = "Delete";
            Delete.UseVisualStyleBackColor = true;
            Delete.Click += Delete_Click;
            // 
            // Subscribe
            // 
            Subscribe.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            Subscribe.Location = new Point(546, 203);
            Subscribe.Name = "Subscribe";
            Subscribe.Size = new Size(175, 67);
            Subscribe.TabIndex = 8;
            Subscribe.Text = "Subscribe";
            Subscribe.UseVisualStyleBackColor = true;
            Subscribe.Click += Subscribe_Click;
            // 
            // Unsubscribe
            // 
            Unsubscribe.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            Unsubscribe.Location = new Point(546, 344);
            Unsubscribe.Name = "Unsubscribe";
            Unsubscribe.Size = new Size(175, 67);
            Unsubscribe.TabIndex = 9;
            Unsubscribe.Text = "Unsubscribe";
            Unsubscribe.UseVisualStyleBackColor = true;
            Unsubscribe.Click += button4_Click;
            // 
            // Update
            // 
            Update.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            Update.Location = new Point(546, 492);
            Update.Name = "Update";
            Update.Size = new Size(175, 67);
            Update.TabIndex = 10;
            Update.Text = "Update";
            Update.UseVisualStyleBackColor = true;
            Update.Click += Update_Click;
            // 
            // id
            // 
            id.Font = new Font("Segoe UI", 12F);
            id.Location = new Point(260, 194);
            id.Multiline = true;
            id.Name = "id";
            id.Size = new Size(236, 46);
            id.TabIndex = 12;
            // 
            // home
            // 
            home.BackgroundImage = (Image)resources.GetObject("home.BackgroundImage");
            home.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            home.Location = new Point(1176, 12);
            home.Name = "home";
            home.Size = new Size(100, 104);
            home.TabIndex = 13;
            home.UseVisualStyleBackColor = true;
            home.Click += home_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToOrderColumns = true;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(808, 239);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(438, 172);
            dataGridView1.TabIndex = 11;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // dataGridView2
            // 
            dataGridView2.AllowUserToOrderColumns = true;
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Location = new Point(808, 505);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.RowHeadersWidth = 62;
            dataGridView2.Size = new Size(438, 172);
            dataGridView2.TabIndex = 14;
            dataGridView2.CellContentClick += dataGridView2_CellContentClick;
            // 
            // Client
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(1288, 710);
            Controls.Add(dataGridView2);
            Controls.Add(home);
            Controls.Add(id);
            Controls.Add(dataGridView1);
            Controls.Add(Update);
            Controls.Add(Unsubscribe);
            Controls.Add(Subscribe);
            Controls.Add(Delete);
            Controls.Add(ADD);
            Controls.Add(contact);
            Controls.Add(address);
            Controls.Add(name);
            Name = "Client";
            Text = "ShopEase Client";
            Load += Client_Load_1;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox name;
        private TextBox address;
        private TextBox contact;
        private Button ADD;
        private Button Delete;
        private Button Subscribe;
        private Button Unsubscribe;
        private Button Update;
        private TextBox id;
        private Button home;
        private DataGridView dataGridView1;
        private DataGridView dataGridView2;
    }
}
﻿namespace yzbtecc
{
    partial class Product
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Product));
            price = new TextBox();
            ID = new TextBox();
            color = new TextBox();
            type = new TextBox();
            size = new TextBox();
            stock = new TextBox();
            add = new Button();
            delete = new Button();
            update = new Button();
            dataGridView1 = new DataGridView();
            home = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // price
            // 
            price.Font = new Font("Segoe UI", 12F);
            price.Location = new Point(238, 482);
            price.Multiline = true;
            price.Name = "price";
            price.Size = new Size(236, 46);
            price.TabIndex = 13;
            price.TextChanged += price_TextChanged;
            // 
            // ID
            // 
            ID.Font = new Font("Segoe UI", 12F);
            ID.Location = new Point(238, 196);
            ID.Multiline = true;
            ID.Name = "ID";
            ID.Size = new Size(236, 46);
            ID.TabIndex = 13;
            ID.TextChanged += ID_TextChanged;
            // 
            // color
            // 
            color.Font = new Font("Segoe UI", 12F);
            color.Location = new Point(238, 411);
            color.Multiline = true;
            color.Name = "color";
            color.Size = new Size(236, 46);
            color.TabIndex = 14;
            color.TextChanged += color_TextChanged;
            // 
            // type
            // 
            type.Font = new Font("Segoe UI", 12F);
            type.Location = new Point(238, 268);
            type.Multiline = true;
            type.Name = "type";
            type.Size = new Size(236, 46);
            type.TabIndex = 14;
            type.TextChanged += type_TextChanged;
            // 
            // size
            // 
            size.Font = new Font("Segoe UI", 12F);
            size.Location = new Point(238, 337);
            size.Multiline = true;
            size.Name = "size";
            size.Size = new Size(236, 46);
            size.TabIndex = 15;
            size.TextChanged += size_TextChanged;
            // 
            // stock
            // 
            stock.Font = new Font("Segoe UI", 12F);
            stock.Location = new Point(238, 561);
            stock.Multiline = true;
            stock.Name = "stock";
            stock.Size = new Size(236, 46);
            stock.TabIndex = 16;
            stock.TextChanged += stock_TextChanged;
            // 
            // add
            // 
            add.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            add.Location = new Point(514, 182);
            add.Name = "add";
            add.Size = new Size(175, 67);
            add.TabIndex = 17;
            add.Text = "ADD";
            add.UseVisualStyleBackColor = true;
            add.Click += add_Click_1;
            // 
            // delete
            // 
            delete.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            delete.Location = new Point(514, 355);
            delete.Name = "delete";
            delete.Size = new Size(175, 67);
            delete.TabIndex = 18;
            delete.Text = "DELETE";
            delete.UseVisualStyleBackColor = true;
            delete.Click += delete_Click_1;
            // 
            // update
            // 
            update.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            update.Location = new Point(514, 527);
            update.Name = "update";
            update.Size = new Size(175, 67);
            update.TabIndex = 18;
            update.Text = "UPDATE";
            update.UseVisualStyleBackColor = true;
            update.Click += update_Click_1;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(775, 289);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(501, 239);
            dataGridView1.TabIndex = 20;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // home
            // 
            home.BackgroundImage = (Image)resources.GetObject("home.BackgroundImage");
            home.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            home.Location = new Point(1176, 12);
            home.Name = "home";
            home.Size = new Size(100, 104);
            home.TabIndex = 21;
            home.UseVisualStyleBackColor = true;
            home.Click += home_Click;
            // 
            // Product
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(1288, 688);
            Controls.Add(home);
            Controls.Add(dataGridView1);
            Controls.Add(update);
            Controls.Add(delete);
            Controls.Add(add);
            Controls.Add(stock);
            Controls.Add(size);
            Controls.Add(type);
            Controls.Add(color);
            Controls.Add(ID);
            Controls.Add(price);
            Name = "Product";
            Text = "ShopEase Product";
            Load += Product_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox price;
        private TextBox ID;
        private TextBox color;
        private TextBox type;
        private TextBox size;
        private TextBox stock;
        private Button add;
        private Button delete;
        private Button update;
        private DataGridView dataGridView1;
        private Button home;
    }
}
﻿namespace yzbtecc
{
    partial class Analytics
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Analytics));
            product = new Button();
            sales = new Button();
            customer = new Button();
            home = new Button();
            SuspendLayout();
            // 
            // product
            // 
            product.BackColor = Color.FromArgb(255, 224, 192);
            product.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            product.Location = new Point(186, 204);
            product.Name = "product";
            product.Size = new Size(261, 446);
            product.TabIndex = 9;
            product.Text = "Product Trends";
            product.UseVisualStyleBackColor = false;
            product.Click += product_Click;
            // 
            // sales
            // 
            sales.BackColor = Color.FromArgb(255, 224, 192);
            sales.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            sales.Location = new Point(515, 204);
            sales.Name = "sales";
            sales.Size = new Size(261, 446);
            sales.TabIndex = 10;
            sales.Text = "Sales Report";
            sales.UseVisualStyleBackColor = false;
            sales.Click += sales_Click;
            // 
            // customer
            // 
            customer.BackColor = Color.FromArgb(255, 224, 192);
            customer.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            customer.Location = new Point(847, 204);
            customer.Name = "customer";
            customer.Size = new Size(261, 446);
            customer.TabIndex = 11;
            customer.Text = "Customer Behavior";
            customer.UseVisualStyleBackColor = false;
            customer.Click += customer_Click;
            // 
            // home
            // 
            home.BackgroundImage = (Image)resources.GetObject("home.BackgroundImage");
            home.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            home.Location = new Point(1176, 12);
            home.Name = "home";
            home.Size = new Size(100, 104);
            home.TabIndex = 14;
            home.UseVisualStyleBackColor = true;
            home.Click += home_Click;
            // 
            // Analytics
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(1288, 710);
            Controls.Add(home);
            Controls.Add(customer);
            Controls.Add(sales);
            Controls.Add(product);
            Name = "Analytics";
            Text = "ShopEase Analytics";
            Load += Analytics_Load;
            ResumeLayout(false);
        }

        #endregion

        private Button product;
        private Button sales;
        private Button customer;
        private Button home;
    }
}
﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;

namespace yzbtecc
{
    public partial class Notification : Form
    {
        // MySQL connection string
        string connectionString = "server=localhost;database=shopease;uid=root;pwd=;";

        public Notification()
        {
            InitializeComponent();
            LoadNotifications();  // Load existing notifications when the form loads
        }
        private void notifications_TextChanged(object sender, EventArgs e)
        {

        }
        // Method to load all notifications into the DataGridView
        private void LoadNotifications()
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT * FROM notifications";  // Fetch all notifications
                    using (MySqlDataAdapter adapter = new MySqlDataAdapter(query, conn))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        dataGridView1.DataSource = dataTable;  // Bind data to DataGridView
                        dataGridView1.Refresh();  // Refresh DataGridView
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        // SEND Button Click Event: Sends a manual notification to all subscribers
        private void send_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string notificationMessage = notifications.Text;  // Get the notification text from the TextBox

                    // Ensure the notification message is not empty
                    if (string.IsNullOrEmpty(notificationMessage))
                    {
                        MessageBox.Show("Please enter a notification message.");
                        return;
                    }

                    // Fetch all subscribers and send the notification
                    string getSubscribersQuery = "SELECT name FROM subscribers";
                    using (MySqlCommand cmd = new MySqlCommand(getSubscribersQuery, conn))
                    {
                        using (MySqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                string subscriberName = reader["name"].ToString();

                                // Insert the notification for each subscriber
                                string insertNotificationQuery = "INSERT INTO notifications (name, notification) VALUES (@name, @notification)";
                                using (MySqlConnection conn2 = new MySqlConnection(connectionString))
                                {
                                    conn2.Open();
                                    using (MySqlCommand notificationCmd = new MySqlCommand(insertNotificationQuery, conn2))
                                    {
                                        notificationCmd.Parameters.AddWithValue("@name", subscriberName);
                                        notificationCmd.Parameters.AddWithValue("@notification", notificationMessage);
                                        notificationCmd.ExecuteNonQuery();
                                    }
                                }
                            }
                        }
                    }

                    // Show confirmation message
                    MessageBox.Show("Notification sent successfully to all subscribers!");

                    // Refresh DataGridView to show new notifications
                    LoadNotifications();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error sending notifications: " + ex.Message);
            }
        }

        // CLEAR Button Click Event: Clears all notifications from the notifications table
        private void clear_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string clearQuery = "DELETE FROM notifications";  // Query to clear all notifications
                    using (MySqlCommand cmd = new MySqlCommand(clearQuery, conn))
                    {
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("All notifications cleared!");

                        // Refresh DataGridView after clearing notifications
                        LoadNotifications();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error clearing notifications: " + ex.Message);
            }
        }

        // Home button to navigate back to the main form
        private void home_Click_1(object sender, EventArgs e)
        {
            // Create an instance of the Main form
            Main mainForm = new Main();

            // Show the Main form
            mainForm.Show();

            // Optionally, hide the current (Notification) form
            this.Hide();
        }

        // Optional: Handle DataGridView row click event (if needed for further actions)
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // You can handle row click events here if needed
        }

        private void Notification_Load(object sender, EventArgs e)
        {

        }
    }
}

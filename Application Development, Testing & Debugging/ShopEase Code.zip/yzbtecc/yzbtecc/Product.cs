﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace yzbtecc
{
    public partial class Product : Form
    {
        // Define the connection string to connect to your MySQL database
        string connectionString = "server=localhost;database=shopease;uid=root;pwd=;";

        public Product()
        {
            InitializeComponent();
        }

        // Form Load Event (called when the form is opened)
        private void Product_Load(object sender, EventArgs e)
        {
            LoadProducts();  // Load all products into the DataGridView
        }

        // Method to load all products from the database into the DataGridView
        private void LoadProducts()
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT * FROM products";  // Query to fetch all products
                    using (MySqlDataAdapter adapter = new MySqlDataAdapter(query, conn))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        dataGridView1.DataSource = dataTable;  // Bind data to DataGridView
                        dataGridView1.Refresh();  // Refresh the DataGridView
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading products: " + ex.Message);
            }
        }

        // Helper method to validate input fields
        private bool ValidateInput()
        {
            // Check if required fields are empty
            if (string.IsNullOrEmpty(type.Text) || string.IsNullOrEmpty(size.Text) || string.IsNullOrEmpty(color.Text)
                || string.IsNullOrEmpty(price.Text) || string.IsNullOrEmpty(stock.Text))
            {
                MessageBox.Show("All fields (Type, Size, Color, Price, Stock) must be filled.");
                return false;
            }

            // Validate Product Name length (min 1, max 50 characters)
            if (type.Text.Length > 50)
            {
                MessageBox.Show("Product name must be between 1 and 50 characters.");
                return false;
            }

            // Validate numeric values for price and stock
            if (!decimal.TryParse(price.Text, out _) || !int.TryParse(stock.Text, out _))
            {
                MessageBox.Show("Price and stock must be valid numbers.");
                return false;
            }

            // Ensure stock and price are positive numbers
            if (decimal.Parse(price.Text) <= 0 || int.Parse(stock.Text) <= 0)
            {
                MessageBox.Show("Price and stock must be greater than zero.");
                return false;
            }

            // Validate Color (No special characters allowed)
            if (!Regex.IsMatch(color.Text, @"^[a-zA-Z\s]+$"))
            {
                MessageBox.Show("Color can only contain letters and spaces.");
                return false;
            }

            return true;
        }

        // ADD Button Click Event
        private void add_Click_1(object sender, EventArgs e)
        {
            if (!ValidateInput()) return;

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    // Insert product into the products table
                    string query = "INSERT INTO products (type, size, color, price, stock) VALUES (@type, @size, @color, @price, @stock)";
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@type", type.Text);
                        cmd.Parameters.AddWithValue("@size", size.Text);
                        cmd.Parameters.AddWithValue("@color", color.Text);
                        cmd.Parameters.AddWithValue("@price", price.Text);
                        cmd.Parameters.AddWithValue("@stock", stock.Text);

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Product added successfully!");

                        LoadProducts();  // Refresh DataGridView after adding
                    }

                    // Notify all subscribers about the new product
                    string notificationMessage = $"New product added, type = {type.Text}, size = {size.Text}, color = {color.Text}, price = {price.Text}$, stock = {stock.Text}";
                    NotifySubscribers(conn, notificationMessage);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: Could not connect to the database. Please check your connection");
            }
        }

        // Helper method to send notification to all subscribers
        private void NotifySubscribers(MySqlConnection conn, string message)
        {
            try
            {
                List<string> subscriberNames = new List<string>();

                // Fetch all subscriber names first
                string query = "SELECT name FROM subscribers";
                using (MySqlCommand cmd = new MySqlCommand(query, conn))
                {
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            subscriberNames.Add(reader["name"].ToString());
                        }
                        reader.Close(); // Close the reader after fetching data
                    }
                }

                // Now insert notifications for each subscriber
                foreach (string subscriberName in subscriberNames)
                {
                    string insertNotificationQuery = "INSERT INTO notifications (name, notification) VALUES (@name, @notification)";
                    using (MySqlCommand notificationCmd = new MySqlCommand(insertNotificationQuery, conn))
                    {
                        notificationCmd.Parameters.AddWithValue("@name", subscriberName);
                        notificationCmd.Parameters.AddWithValue("@notification", message);
                        notificationCmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error sending notifications: " + ex.Message);
            }
        }

        // DELETE Button Click Event
        private void delete_Click_1(object sender, EventArgs e)
        {
            // Check if the ID field is empty
            if (string.IsNullOrEmpty(ID.Text))
            {
                MessageBox.Show("Please select a product to delete.", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    // First, check if the product exists with the given ID
                    string checkQuery = "SELECT COUNT(*) FROM products WHERE id = @id";
                    using (MySqlCommand checkCmd = new MySqlCommand(checkQuery, conn))
                    {
                        checkCmd.Parameters.AddWithValue("@id", ID.Text);
                        int productCount = Convert.ToInt32(checkCmd.ExecuteScalar());

                        // If the product doesn't exist, show an error message
                        if (productCount == 0)
                        {
                            MessageBox.Show("No product found with the given ID.", "Product Not Found", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return;
                        }
                    }

                    // If the product exists, proceed to delete it
                    string query = "DELETE FROM products WHERE id = @id";
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", ID.Text);  // Ensure ID is provided
                        cmd.ExecuteNonQuery();

                        MessageBox.Show("Product deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        // Refresh DataGridView after deletion
                        LoadProducts();
                    }
                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Error: Could not connect to the database. Please check your connection.", "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting product: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        // UPDATE Button Click Event
        // UPDATE Button Click Event
        private void update_Click_1(object sender, EventArgs e)
        {
            // Check if the ID field is empty
            if (string.IsNullOrWhiteSpace(ID.Text))
            {
                MessageBox.Show("Product ID is required for updating a product.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "UPDATE products SET type = @type, size = @size, color = @color, price = @price, stock = @stock WHERE id = @id";
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", ID.Text);  // Make sure ID is provided
                        cmd.Parameters.AddWithValue("@type", type.Text);
                        cmd.Parameters.AddWithValue("@size", size.Text);
                        cmd.Parameters.AddWithValue("@color", color.Text);
                        cmd.Parameters.AddWithValue("@price", price.Text);
                        cmd.Parameters.AddWithValue("@stock", stock.Text);

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Product updated successfully!");

                        LoadProducts();  // Refresh DataGridView after updating
                    }

                    // Notify all subscribers about the product update
                    string notificationMessage = $"Product updated, type = {type.Text}, size = {size.Text}, color = {color.Text}, price = {price.Text}$, stock = {stock.Text}";
                    NotifySubscribers(conn, notificationMessage);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }


        // Handle DataGridView Row Click to load selected product details into TextBoxes
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];

                // Fill the TextBoxes with selected row's data
                ID.Text = row.Cells["id"].Value.ToString();
                type.Text = row.Cells["type"].Value.ToString();
                size.Text = row.Cells["size"].Value.ToString();
                color.Text = row.Cells["color"].Value.ToString();
                price.Text = row.Cells["price"].Value.ToString();
                stock.Text = row.Cells["stock"].Value.ToString();
            }
        }

        private void home_Click(object sender, EventArgs e)
        {
            // Create an instance of the Main form
            Main mainForm = new Main();

            // Show the Main form
            mainForm.Show();

            // Optionally, hide the current (Product) form
            this.Hide();
        }
  



private void type_TextChanged(object sender, EventArgs e)
        {

        }

        private void size_TextChanged(object sender, EventArgs e)
        {

        }

        private void ID_TextChanged(object sender, EventArgs e)
        {

        }

        private void color_TextChanged(object sender, EventArgs e)
        {

        }

        private void price_TextChanged(object sender, EventArgs e)
        {

        }

        private void stock_TextChanged(object sender, EventArgs e)
        {

        }
        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

      
    }
}

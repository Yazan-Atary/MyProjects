﻿using System;
using System.Data;
using System.Windows.Forms;

namespace yzbtecc
{
    public partial class Result : Form
    {
        public Result()
        {
            InitializeComponent();
        }

        // Public method to set the DataSource for dataGridView1
        public void SetDataGridSource(DataTable dataTable)
        {
            dataGridView1.DataSource = dataTable;
        }

        private void Result_Load(object sender, EventArgs e)
        {

        }

        private void back_Click(object sender, EventArgs e)
        {
            // Create an instance of the Analytics form
            Analytics analyticsForm = new Analytics();
            analyticsForm.Show();
            this.Hide();  // Optionally hide current form
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

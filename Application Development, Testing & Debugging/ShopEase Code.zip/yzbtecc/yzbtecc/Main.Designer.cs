﻿namespace yzbtecc
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            analytics_report = new Button();
            notification_management = new Button();
            product_management = new Button();
            client_management = new Button();
            SuspendLayout();
            // 
            // analytics_report
            // 
            analytics_report.BackColor = Color.FromArgb(255, 224, 192);
            analytics_report.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point, 0);
            analytics_report.Location = new Point(808, 199);
            analytics_report.Name = "analytics_report";
            analytics_report.Size = new Size(218, 426);
            analytics_report.TabIndex = 11;
            analytics_report.Text = "Analytics  and Reporting";
            analytics_report.UseVisualStyleBackColor = false;
            analytics_report.Click += analytics_report_Click;
            // 
            // notification_management
            // 
            notification_management.BackColor = Color.FromArgb(255, 224, 192);
            notification_management.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point, 0);
            notification_management.Location = new Point(558, 199);
            notification_management.Name = "notification_management";
            notification_management.Size = new Size(218, 426);
            notification_management.TabIndex = 10;
            notification_management.Text = "Notifications Management";
            notification_management.UseVisualStyleBackColor = false;
            notification_management.Click += notification_management_Click;
            // 
            // product_management
            // 
            product_management.BackColor = Color.FromArgb(255, 224, 192);
            product_management.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point, 0);
            product_management.Location = new Point(302, 199);
            product_management.Name = "product_management";
            product_management.Size = new Size(218, 426);
            product_management.TabIndex = 9;
            product_management.Text = "Product Management";
            product_management.UseVisualStyleBackColor = false;
            product_management.Click += button2_Click;
            // 
            // client_management
            // 
            client_management.BackColor = Color.FromArgb(255, 224, 192);
            client_management.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            client_management.Location = new Point(39, 199);
            client_management.Name = "client_management";
            client_management.Size = new Size(218, 426);
            client_management.TabIndex = 8;
            client_management.Text = "Client Management";
            client_management.UseVisualStyleBackColor = false;
            client_management.Click += client_management_Click;
            // 
            // Main
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(1071, 686);
            Controls.Add(analytics_report);
            Controls.Add(notification_management);
            Controls.Add(product_management);
            Controls.Add(client_management);
            Name = "Main";
            Text = "ShopEase Main";
            ResumeLayout(false);
        }

        #endregion

        private Button analytics_report;
        private Button notification_management;
        private Button product_management;
        private Button client_management;
    }
}
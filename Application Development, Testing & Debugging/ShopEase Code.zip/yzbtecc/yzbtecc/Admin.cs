namespace yzbtecc
{
    public partial class Admin : Form
    {
        public Admin()
        {
            InitializeComponent();
        }




        private void username_TextChanged(object sender, EventArgs e)
        {

        }

        private void password_TextChanged(object sender, EventArgs e)
        {
            password.PasswordChar = '*';

        }


        private void submit_Click(object sender, EventArgs e)
        {
            try
            {
                string username1 = username.Text;
                string password1 = password.Text;

                // Validate username and password
                if (username1 == "admin" && password1 == "admin")
                {
                    // Login successful, open the correct Main Dashboard form
                    Main mainform = new Main();
                    mainform.Show();
                    this.Hide();
                }
                else
                {
                    // Login failed, show error message
                    MessageBox.Show("Invalid username or password. Please try again.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                // Handle any unexpected errors
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Admin_Load(object sender, EventArgs e)
        {

        }
    }
}


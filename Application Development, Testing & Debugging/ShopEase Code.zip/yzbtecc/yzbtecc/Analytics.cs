﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;

namespace yzbtecc
{
    public partial class Analytics : Form
    {
        string connectionString = "server=localhost;database=shopease;uid=root;pwd=;";

        public Analytics()
        {
            InitializeComponent();
        }

        private void Analytics_Load(object sender, EventArgs e)
        {

        }

        private void home_Click(object sender, EventArgs e)
        {
            // Create an instance of the Main form
            Main mainForm = new Main();
            mainForm.Show();
            this.Hide();
        }

        // Product Trends Button Click Event
        // Product Trends Button Click Event
        private void product_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    // Select products with their current stock from the database
                    string query = "SELECT type, stock FROM products";  // Fetch product type and stock from the 'products' table
                    using (MySqlDataAdapter adapter = new MySqlDataAdapter(query, conn))
                    {
                        DataTable productTable = new DataTable();
                        adapter.Fill(productTable);

                        // Add columns for "Total Sold" and "Forecast Demand" to the productTable
                        productTable.Columns.Add("TotalSold", typeof(int));
                        productTable.Columns.Add("ForecastDemand", typeof(string));

                        Random random = new Random();
                        foreach (DataRow row in productTable.Rows)
                        {
                            // Generate random total sold between 50 and 500
                            int totalSold = random.Next(50, 500);
                            row["TotalSold"] = totalSold;

                            // Determine forecast demand based on total sold
                            if (totalSold >= 200)
                            {
                                row["ForecastDemand"] = "High";
                            }
                            else if (totalSold >= 100)
                            {
                                row["ForecastDemand"] = "Medium";
                            } 
                            else
                            {
                                row["ForecastDemand"] = "Low";
                            }
                        }

                        // Show results in the DataGridView of Result Form
                        Result resultForm = new Result();
                        resultForm.SetDataGridSource(productTable);  // Call public method to set data
                        resultForm.Show();  // Open the results form
                        this.Hide();  // Optionally hide current form
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }



        // Sales Report Button Click Event
        private void sales_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    // Query to get product types and total revenue
                    string query = "SELECT type, SUM(price * stock) AS TotalRevenue FROM products GROUP BY type";
                    using (MySqlDataAdapter adapter = new MySqlDataAdapter(query, conn))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // Add a new column for random QuantitySold
                        dataTable.Columns.Add("QuantitySold", typeof(int));

                        Random random = new Random();
                        foreach (DataRow row in dataTable.Rows)
                        {
                            // Assign a random value for QuantitySold between 1 and 50
                            row["QuantitySold"] = random.Next(1, 51);
                        }

                        // Show results in the DataGridView of Result Form
                        Result resultForm = new Result();
                        resultForm.SetDataGridSource(dataTable);  // Call public method to set data
                        resultForm.Show();  // Open the results form
                        this.Hide();  // Optionally hide current form
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        // Customer Behavior Button Click Event
        // Customer Behavior Report Button Click Event
        private void customer_Click(object sender, EventArgs e)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    // Query to get random products for 'MostViewedProduct'
                    string productQuery = "SELECT type FROM products ORDER BY RAND() LIMIT 1";
                    using (MySqlDataAdapter productAdapter = new MySqlDataAdapter(productQuery, conn))
                    {
                        DataTable productTable = new DataTable();
                        productAdapter.Fill(productTable);

                        // Sample customers for the demo (In a real application, you would fetch real customer data)
                        DataTable customerTable = new DataTable();
                        customerTable.Columns.Add("Customer", typeof(string));
                        customerTable.Columns.Add("MostViewedProduct", typeof(string));  // Random product from the 'products' table
                        customerTable.Columns.Add("AverageSpend", typeof(string));  // Random average spend

                        // Simulate customers (example data)
                        string[] customers = { "Khaled", "Yazan", "Mohammed" };

                        Random random = new Random();
                        foreach (string customer in customers)
                        {
                            // Get a random product from the productTable
                            string mostViewedProduct = productTable.Rows[0]["type"].ToString();

                            // Generate a random value for average spend
                            string averageSpend = random.Next(100, 1000).ToString() + "$";  // Random amount between 100 and 1000 dollars

                            // Add rows to the customerTable
                            customerTable.Rows.Add(customer, mostViewedProduct, averageSpend);
                        }

                        // Show results in the DataGridView of Result Form
                        Result resultForm = new Result();
                        resultForm.SetDataGridSource(customerTable);  // Call public method to set data
                        resultForm.Show();  // Open the results form
                        this.Hide();  // Optionally hide current form
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

    }
}

﻿namespace yzbtecc
{
    partial class Notification
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Notification));
            notifications = new TextBox();
            send = new Button();
            dataGridView1 = new DataGridView();
            home = new Button();
            clear = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // notifications
            // 
            notifications.Font = new Font("Segoe UI", 12F);
            notifications.Location = new Point(503, 198);
            notifications.Multiline = true;
            notifications.Name = "notifications";
            notifications.Size = new Size(535, 46);
            notifications.TabIndex = 0;
            notifications.TextChanged += notifications_TextChanged;
            // 
            // send
            // 
            send.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            send.Location = new Point(1077, 184);
            send.Name = "send";
            send.Size = new Size(175, 67);
            send.TabIndex = 18;
            send.Text = "SEND";
            send.UseVisualStyleBackColor = true;
            send.Click += send_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(69, 377);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.Size = new Size(1147, 271);
            dataGridView1.TabIndex = 19;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // home
            // 
            home.BackgroundImage = (Image)resources.GetObject("home.BackgroundImage");
            home.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            home.Location = new Point(1176, 12);
            home.Name = "home";
            home.Size = new Size(100, 104);
            home.TabIndex = 22;
            home.UseVisualStyleBackColor = true;
            home.Click += home_Click_1;
            // 
            // clear
            // 
            clear.FlatStyle = FlatStyle.Flat;
            clear.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
            clear.Location = new Point(69, 304);
            clear.Name = "clear";
            clear.Size = new Size(175, 67);
            clear.TabIndex = 23;
            clear.Text = "Clear all";
            clear.UseVisualStyleBackColor = true;
            clear.Click += clear_Click;
            // 
            // Notification
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(1288, 688);
            Controls.Add(clear);
            Controls.Add(home);
            Controls.Add(dataGridView1);
            Controls.Add(send);
            Controls.Add(notifications);
            Name = "Notification";
            Text = "ShopEase Notification";
            Load += Notification_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox notifications;
        private Button send;
        private DataGridView dataGridView1;
        private Button home;
        private Button clear;
    }
}
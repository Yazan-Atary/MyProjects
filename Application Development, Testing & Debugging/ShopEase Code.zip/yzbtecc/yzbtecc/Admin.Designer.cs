﻿namespace yzbtecc
{
    partial class Admin
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin));
            submit = new Button();
            password = new TextBox();
            username = new TextBox();
            SuspendLayout();
            // 
            // submit
            // 
            submit.BackgroundImageLayout = ImageLayout.None;
            submit.Font = new Font("MS Reference Sans Serif", 14F, FontStyle.Bold);
            submit.Location = new Point(489, 523);
            submit.Name = "submit";
            submit.Size = new Size(168, 46);
            submit.TabIndex = 8;
            submit.Text = "Submit";
            submit.UseVisualStyleBackColor = true;
            submit.Click += submit_Click;
            // 
            // password
            // 
            password.Font = new Font("Segoe UI", 11F);
            password.Location = new Point(462, 402);
            password.Name = "password";
            password.Size = new Size(267, 37);
            password.TabIndex = 7;
            password.TextChanged += password_TextChanged;
            // 
            // username
            // 
            username.Font = new Font("Segoe UI", 11F);
            username.Location = new Point(462, 284);
            username.Name = "username";
            username.Size = new Size(267, 37);
            username.TabIndex = 6;
            username.TextChanged += username_TextChanged;
            // 
            // Admin
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(1071, 686);
            Controls.Add(submit);
            Controls.Add(password);
            Controls.Add(username);
            Name = "Admin";
            Text = "ShopEase Admin";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button submit;
        private TextBox password;
        private TextBox username;
    }
}

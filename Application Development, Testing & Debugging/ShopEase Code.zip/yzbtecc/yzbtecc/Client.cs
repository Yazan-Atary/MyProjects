﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;

namespace yzbtecc
{
    public partial class Client : Form
    {
        // Define your MySQL connection string here
        string connectionString = "server=localhost;database=shopease;uid=root;pwd=;";

        public Client()
        {
            InitializeComponent();
        }

        // ADD Button Click Event: Adds a new client to the database
        private void ADD_Click(object sender, EventArgs e)
        {
            // Check if any of the required fields are empty
            if (string.IsNullOrEmpty(name.Text) || string.IsNullOrEmpty(address.Text) || string.IsNullOrEmpty(contact.Text))
            {
                MessageBox.Show("All fields (Name, Address, and Contact) are required.", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;  // Stop execution if any field is empty
            }

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "INSERT INTO clients (name, address, contact) VALUES (@name, @address, @contact)";
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@name", name.Text);
                        cmd.Parameters.AddWithValue("@address", address.Text);
                        cmd.Parameters.AddWithValue("@contact", contact.Text);

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Client added successfully!");

                        // Refresh the DataGridView after adding a new client
                        LoadClients();  // This will reload the clients from the database
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        // DELETE Button Click Event: Deletes a client from the database
        private void Delete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(id.Text))
            {
                MessageBox.Show("Please select a client to delete.");
                return;
            }

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    // Start a transaction to ensure both deletes happen atomically
                    using (MySqlTransaction transaction = conn.BeginTransaction())
                    {
                        try
                        {
                            // Delete from subscribers first (if the client exists there)
                            string deleteSubscribersQuery = "DELETE FROM subscribers WHERE id = @id";
                            using (MySqlCommand cmd = new MySqlCommand(deleteSubscribersQuery, conn, transaction))
                            {
                                cmd.Parameters.AddWithValue("@id", id.Text);
                                cmd.ExecuteNonQuery();
                            }

                            // Delete from clients
                            string deleteClientsQuery = "DELETE FROM clients WHERE id = @id";
                            using (MySqlCommand cmd = new MySqlCommand(deleteClientsQuery, conn, transaction))
                            {
                                cmd.Parameters.AddWithValue("@id", id.Text);
                                cmd.ExecuteNonQuery();
                            }

                            // Commit the transaction if both delete operations are successful
                            transaction.Commit();

                            MessageBox.Show("Client and their subscription (if any) deleted successfully!");

                            LoadClients();       // Refresh clients list
                            LoadSubscribers();   // Refresh subscribers list
                        }
                        catch (Exception ex)
                        {
                            // Rollback the transaction if something goes wrong
                            transaction.Rollback();
                            MessageBox.Show("Error during deletion: " + ex.Message);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }


        // UPDATE Button Click Event: Updates an existing client in the database
        private void Update_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(id.Text))
            {
                MessageBox.Show("Please select a client to update.");
                return;
            }

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    // Start a transaction to ensure all updates happen atomically
                    using (MySqlTransaction transaction = conn.BeginTransaction())
                    {
                        try
                        {
                            // Update the client details in the clients table
                            string updateClientsQuery = "UPDATE clients SET name = @name, address = @address, contact = @contact WHERE id = @id";
                            using (MySqlCommand cmd = new MySqlCommand(updateClientsQuery, conn, transaction))
                            {
                                cmd.Parameters.AddWithValue("@id", id.Text);
                                cmd.Parameters.AddWithValue("@name", name.Text);
                                cmd.Parameters.AddWithValue("@address", address.Text);
                                cmd.Parameters.AddWithValue("@contact", contact.Text);

                                cmd.ExecuteNonQuery();
                            }

                            // Update the client details in the subscribers table (if the client is subscribed)
                            string updateSubscribersQuery = "UPDATE subscribers SET name = @name WHERE id = @id";
                            using (MySqlCommand cmd = new MySqlCommand(updateSubscribersQuery, conn, transaction))
                            {
                                cmd.Parameters.AddWithValue("@id", id.Text);
                                cmd.Parameters.AddWithValue("@name", name.Text);

                                cmd.ExecuteNonQuery();
                            }

                            // Update the subscriber's name in the notifications table
                            string updateNotificationsQuery = "UPDATE notifications SET name = @name WHERE name = (SELECT name FROM subscribers WHERE id = @id)";
                            using (MySqlCommand cmd = new MySqlCommand(updateNotificationsQuery, conn, transaction))
                            {
                                cmd.Parameters.AddWithValue("@id", id.Text);
                                cmd.Parameters.AddWithValue("@name", name.Text);

                                cmd.ExecuteNonQuery();
                            }

                            // Commit the transaction if all updates are successful
                            transaction.Commit();

                            MessageBox.Show("Client details updated successfully!");

                            // Refresh the data in the DataGridView controls
                            LoadClients();
                            LoadSubscribers();
                        }
                        catch (Exception ex)
                        {
                            // Rollback the transaction if any error occurs
                            transaction.Rollback();
                            MessageBox.Show("Error during update: " + ex.Message);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }




        // Method to load all clients into the ListBox when the form loads
        private void LoadClients()
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT * FROM clients";  // Query to fetch all clients from the database
                    using (MySqlDataAdapter adapter = new MySqlDataAdapter(query, conn))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // Bind the DataTable to the DataGridView
                        dataGridView1.DataSource = dataTable;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        // Call LoadClients when the form loads to automatically show clients in the DataGridView
        private void Subscribe_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(id.Text))
            {
                MessageBox.Show("Please select a client to subscribe.");
                return;
            }

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "INSERT INTO subscribers (id, name, address, contact) SELECT id, name, address, contact FROM clients WHERE id = @id";
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", id.Text);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Client subscribed successfully!");

                        LoadSubscribers();  // Refresh DataGridView2 after subscribing
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        // Unsubscribe Button Click Event: Removes the current client from the subscribers table
        private void button4_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(id.Text))
            {
                MessageBox.Show("Please select a client to unsubscribe.");
                return;
            }

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "DELETE FROM subscribers WHERE id = @id";
                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@id", id.Text);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Client unsubscribed successfully!");

                        LoadSubscribers();  // Refresh DataGridView2 after unsubscribing
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        // Method to load all subscribers into the DataGridView2
        private void LoadSubscribers()
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "SELECT * FROM subscribers";  // Query to fetch all subscribers from the database
                    using (MySqlDataAdapter adapter = new MySqlDataAdapter(query, conn))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // Bind the DataTable to the DataGridView2 (subscribers list)
                        dataGridView2.DataSource = dataTable;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        // Call LoadSubscribers when the form loads to automatically show subscribers in the DataGridView2
        private void Client_Load_1(object sender, EventArgs e)
        {
            LoadClients();  // Automatically load clients when the form opens
            LoadSubscribers();  // Automatically load subscribers when the form opens
        }

        // Handle DataGridView Row Click (Optional, to populate TextBoxes with selected row data)
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];

                // Populate textboxes with the selected row's data
                id.Text = row.Cells["id"].Value.ToString();
                name.Text = row.Cells["name"].Value.ToString();
                address.Text = row.Cells["address"].Value.ToString();
                contact.Text = row.Cells["contact"].Value.ToString();
            }
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Handle clicks on DataGridView2 for subscribers if needed.
        }

        private void home_Click(object sender, EventArgs e)
        {
            // Create an instance of the Main form
            Main mainForm = new Main();

            // Show the Main form
            mainForm.Show();

            // Optionally, hide the current (Client) form
            this.Hide();
        }
    }
}
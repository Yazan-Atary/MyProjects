package javaapplication86;

import java.util.Stack;

public class FolderStack {
    private Stack<Integer> folderStack;

    public FolderStack() {
        folderStack = new Stack<>();
    }

    public void pushFolder(int folderID) {
        folderStack.push(folderID);
    }

    public int popFolder() {
        return folderStack.pop();
    }

    public int peekFolder() {
        return folderStack.peek();
    }

    public boolean isEmpty() {
        return folderStack.isEmpty();
    }
}
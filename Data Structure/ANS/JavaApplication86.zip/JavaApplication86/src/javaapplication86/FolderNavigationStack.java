package javaapplication86;
import java.util.Stack;

public class FolderNavigationStack {

    private Stack<Integer> folderStack;

    public FolderNavigationStack() {
        folderStack = new Stack<>();
    }

    public void openFolder(int folderID) {
        folderStack.push(folderID);
        System.out.println("Opened folder with ID: " + folderID);
    }

    public void navigateBack() {
        if (!folderStack.isEmpty()) {
            int previousFolderID = folderStack.pop();
            System.out.println("Navigated back to folder with ID: " + previousFolderID);
        } else {
            System.out.println("Error: Cannot navigate back. Stack is empty.");
        }
    }

    public void printCurrentStack() {
        System.out.println("Current Folder Stack: " + folderStack);
    }

    public static void main(String[] args) {
        FolderNavigationStack folderNavigation = new FolderNavigationStack();

        // Simulating opening folders and navigating
        folderNavigation.openFolder(1);
        folderNavigation.openFolder(2);
        folderNavigation.openFolder(3);
        folderNavigation.printCurrentStack();

        // Navigating back
        folderNavigation.navigateBack();
        folderNavigation.printCurrentStack();

        // Opening more folders
        folderNavigation.openFolder(4);
        folderNavigation.openFolder(5);
        folderNavigation.printCurrentStack();

        // Navigating back again
        folderNavigation.navigateBack();
        folderNavigation.printCurrentStack();
    }
}
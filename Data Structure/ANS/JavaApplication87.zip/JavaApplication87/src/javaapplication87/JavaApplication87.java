
package javaapplication87;
 
public class JavaApplication87 {
 
    public static void main(String[] args) {
           LinkedStack stack = new LinkedStack();

        // Test the push operation
        stack.push(10);
        stack.push(20);
        stack.push(30);

        // Test the pop operation
        System.out.println("Popped element: " + stack.pop());

        // Test the peek operation
        System.out.println("Top element: " + stack.peek());

        // Test isEmpty and size operations
        System.out.println("Is stack empty? " + stack.isEmpty());
        System.out.println("Size of the stack: " + stack.size());
    }
}